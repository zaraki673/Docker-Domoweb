#!/bin/bash

diff -Nru domoweb-0.1.99.orig domoweb-0.1.99
