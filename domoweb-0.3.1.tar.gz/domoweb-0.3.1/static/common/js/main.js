$(function(){
   	$("body").attr('role', 'application');
});
